# !pip install transformers
# !pip install ckiptagger

import sys

from ckiptagger import data_utils, construct_dictionary, WS
from transformers import AutoTokenizer, BertTokenizerFast, AutoModel, GPT2LMHeadModel 
from transformers import TextGenerationPipeline, AutoModelForCausalLM

#data_utils.download_data_url("./") # gdrive-ckip

ws = WS("./data")

token_key = "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"

tokenizer = BertTokenizerFast.from_pretrained('bert-base-chinese', token=token_key)
model = GPT2LMHeadModel.from_pretrained('ckiplab/gpt2-base-chinese', token=token_key)

# try messing around with the parameters
tokens_size = int(sys.argv[2])
generator = TextGenerationPipeline(model, tokenizer, max_new_tokens=tokens_size, no_repeat_ngram_size=3) #, device=0) #if you have a GPU

#string = "今天"
string = sys.argv[3]

#loop = 5
loop=sys.argv[1]
print(loop)
loop=int(loop)

while loop:
  # print(input_string)
  print()
  output = generator(string)
  string = output[0]['generated_text'].replace(' ', '')
  # print(string)
  string_ws = ws([string])
  string = " ".join(str(x) for x in string_ws[0])
  print(string)
  string = string + '\n'
  loop-=1

'''
max_length=256
input_txt = """
隨著貸款日益枯竭，Alistair Darling 被迫考慮對銀行進行第二次救助。 \
財政大臣將在幾週內決定是否向經濟中再注入數十億美元，因為有證據表明\
去年 370 億的部分國有化未能保持信貸流動，
"""
input_ids = tokenizer(input_txt, return_tensors="pt")["input_ids"]
output = model.generate(input_ids, max_length=max_length, num_beams=1,  do_sample=True, top_k=50)
print(tokenizer.decode(output[0]))
'''

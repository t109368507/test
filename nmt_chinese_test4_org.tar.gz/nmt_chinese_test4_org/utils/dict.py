import sys

'''
Usage:
python cut2.py fpath new_data_dir
'''

def cut2(fpath):
    fp = open(fpath, encoding='utf-8')
    src_fp = open( 'dict.raw', 'w', encoding='utf-8')
    for line in fp.readlines():
        src_line, _ = line.split(' ')
        src_fp.write(src_line + '\n')
    src_fp.close()

if __name__ == '__main__':
    cut2(fpath=sys.argv[1])


# !pip install transformers
# !pip install ckiptagger

import sys

from ckiptagger import data_utils, construct_dictionary, WS
from transformers import AutoTokenizer, BertTokenizerFast, AutoModel, GPT2LMHeadModel 
from transformers import TextGenerationPipeline, AutoModelForCausalLM

#data_utils.download_data_url("./") # gdrive-ckip

ws = WS("./data")

token_key = "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"

tokenizer = BertTokenizerFast.from_pretrained('bert-base-chinese', token=token_key)
model = GPT2LMHeadModel.from_pretrained('ckiplab/gpt2-base-chinese', token=token_key)

# try messing around with the parameters
#tokens_size = int(sys.argv[2])
tokens_size = 10
generator = TextGenerationPipeline(model, tokenizer, max_new_tokens=tokens_size, no_repeat_ngram_size=1) #, device=0) #if you have a GPU


#fp = open("dict.raw", encoding='utf-8')
fp = open("chinese.raw.zh", encoding='utf-8')
tgt_fp = open("chinese.gpt2.zh",'w', encoding='utf-8')

loop=sys.argv[1]

for line in fp.readlines():
    #print("dict.raw ",line)
    #print(len(line))
    if len(line) < 3:
        continue
    string = line
    #string = "今天"
    #string = sys.argv[3]

    #loop = 1
    #loop=sys.argv[1]
    #print(loop)
    
    loop=int(loop)

    if loop == 0:
        break

    ##characters = "。，；、,"
    ##characters = ",。；，?、"
    characters = "。，"

    # print(input_string)
    # print()
    output = generator(string)
    _string = output[0]['generated_text'].replace(' ', '')
  
    string_ws = ws([_string])
    __string = " ".join(str(x) for x in string_ws[0])
  
    #print(string)
    #for x in range(len(characters)):
    #    ____string =___string.replace(characters[x], characters[x]+'\n')
    #print(string)
        
    #___string = __string.replace('\n','')
    #___string = __string.replace('\n','\n')

    ___string = __string.split("\n")

    #for x in range(len(characters)):
    #    ____string =___string[1].replace(characters[x], characters[x]+'\n')
        
    ____string = ___string[1]

    print(____string)
    loop-=1
    tgt_fp.write(____string+ '\n')

tgt_fp.close()

'''
max_length=256
input_txt = """
隨著貸款日益枯竭，Alistair Darling 被迫考慮對銀行進行第二次救助。 \
財政大臣將在幾週內決定是否向經濟中再注入數十億美元，因為有證據表明\
去年 370 億的部分國有化未能保持信貸流動，
"""
input_ids = tokenizer(input_txt, return_tensors="pt")["input_ids"]
output = model.generate(input_ids, max_length=max_length, num_beams=1,  do_sample=True, top_k=50)
print(tokenizer.decode(output[0]))
'''
